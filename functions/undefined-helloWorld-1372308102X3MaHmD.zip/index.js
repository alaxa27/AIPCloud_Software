"use strict";Object.defineProperty(exports, "__esModule", { value: true });exports.generateMonoAudio = exports.helloWorld = undefined;var _firebaseFunctions = require("firebase-functions");var functions = _interopRequireWildcard(_firebaseFunctions);
var _storage = require("@google-cloud/storage");
var _path = require("path");function _interopRequireWildcard(obj) {if (obj && obj.__esModule) {return obj;} else {var newObj = {};if (obj != null) {for (var key in obj) {if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];}}newObj.default = obj;return newObj;}}

var helloWorld = exports.helloWorld = functions.https.onRequest(function (req, res) {
  var world = "from ES6 in Cloud Functions!";
  res.status(200).send("Hello " + world);
});


var path = require('path');
var os = require('os');
var fs = require('fs');
var ffmpeg = require('fluent-ffmpeg');
var ffmpeg_static = require('ffmpeg-static');

/**
                                               * When an audio is uploaded in the Storage bucket We generate a mono channel audio automatically using
                                               * node-fluent-ffmpeg.
                                               */
var generateMonoAudio = exports.generateMonoAudio = functions.storage.object().onChange(function (event) {
  var object = event.data; // The Storage object.

  var fileBucket = object.bucket; // The Storage bucket that contains the file.
  var filePath = object.name; // File path in the bucket.
  var contentType = object.contentType; // File content type.
  var resourceState = object.resourceState; // The resourceState is 'exists' or 'not_exists' (for file/folder deletions).
  var metageneration = object.metageneration; // Number of times metadata has been generated. New objects have a value of 1.

  // Exit if this is triggered on a file that is not an audio.
  if (!contentType.startsWith('audio/')) {
    console.log('This is not an audio.');
    return;
  }

  // Get the file name.
  var fileName = (0, _path.basename)(filePath);
  // Exit if the audio is already converted.
  if (fileName.endsWith('_output.flac')) {
    console.log('Already a converted audio.');
    return;
  }

  // Exit if this is a move or deletion event.
  if (resourceState === 'not_exists') {
    console.log('This is a deletion event.');
    return;
  }

  // Exit if file exists but is not new and is only being triggered
  // because of a metadata change.
  if (resourceState === 'exists' && metageneration > 1) {
    console.log('This is a metadata change event.');
    return;
  }

  // Download file from bucket.
  var bucket = gcs.bucket(fileBucket);
  var tempFilePath = (0, _path.join)(os.tmpdir(), fileName);
  // We add a '_output.flac' suffix to target audio file name. That's where we'll upload the converted audio.
  var targetTempFileName = fileName.replace(/\.[^/.]+$/, "") + '_output.flac';
  var targetTempFilePath = (0, _path.join)(os.tmpdir(), targetTempFileName);
  var targetStorageFilePath = (0, _path.join)((0, _path.dirname)(filePath), targetTempFileName);

  return bucket.file(filePath).download({
    destination: tempFilePath }).
  then(function () {
    console.log('Audio downloaded locally to', tempFilePath);
    // Convert the audio to mono channel using FFMPEG.
    var command = ffmpeg(tempFilePath).
    setFfmpegPath(ffmpeg_static.path).
    audioChannels(1).
    audioFrequency(16000).
    format('flac').
    on('error', function (err) {
      console.log('An error occurred: ' + err.message);
    }).
    on('end', function () {
      console.log('Output audio created at', targetTempFilePath);

      // Uploading the audio.
      return bucket.upload(targetTempFilePath, { destination: targetStorageFilePath }).then(function () {
        console.log('Output audio uploaded to', targetStorageFilePath);

        // Once the audio has been uploaded delete the local file to free up disk space.
        fs.unlinkSync(tempFilePath);
        fs.unlinkSync(targetTempFilePath);

        console.log('Temporary files removed.', targetTempFilePath);
      });
    }).
    save(targetTempFilePath);
  });
});